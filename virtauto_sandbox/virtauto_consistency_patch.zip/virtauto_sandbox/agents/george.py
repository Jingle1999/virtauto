
from typing import Dict, Any
from .quality_agent import QualityAgent
from .procurement_agent import ProcurementAgent
from .supplychain_agent import SupplyChainAgent
from ..common.task import Task, Result
from ..consistency.gate import preflight, postflight
from ..consistency.bridge import precheck as mvp_precheck, postcheck as mvp_postcheck
from ..logging.audit import audit

class GEORGE:
    """Coordinator/Delegator mit internem Gate + MVP-Bridge."""

    def __init__(self):
        self.registry = {
            "quality.analyze_csv": QualityAgent(),
            "procure.suggest_supplier": ProcurementAgent(),
            "sc.plan": SupplyChainAgent(),
        }

    def route(self, task: Task) -> Result:
        # 1) interner Preflight
        ok, errs = preflight(task.__dict__)
        if not ok:
            audit("consistency_pre_fail", {"task_id": task.id, "errors": errs})
            return Result(ok=False, errors=errs)

        # 2) externer MVP-Precheck
        mvp_pre = mvp_precheck(task.__dict__)
        if not mvp_pre.get("ok", True):
            audit("mvp_pre_fail", {"task_id": task.id, "errors": mvp_pre.get("errors", [])})
            return Result(ok=False, errors=mvp_pre.get("errors", ["consistency pre failed"]))

        # Routing
        key = task.type
        agent = self.registry.get(key)
        if not agent:
            return Result(ok=False, errors=[f"no agent for type {key}"])
        audit("route", {"task_id": task.id, "to": agent.name})
        res = agent.handle(task)

        # 3) interner Postflight
        ok2, errs2 = postflight({"data": res.data})
        if not ok2:
            audit("consistency_post_fail", {"task_id": task.id, "errors": errs2})
            res.errors.extend(errs2)
            res.ok = False

        # 4) externer MVP-Postcheck
        mvp_post = mvp_postcheck({"data": res.data})
        if not mvp_post.get("ok", True):
            audit("mvp_post_fail", {"task_id": task.id, "errors": mvp_post.get("errors", [])})
            res.errors.extend(mvp_post.get("errors", []))
            res.ok = False

        return res
