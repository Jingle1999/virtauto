# Reproducible Test Cases (Baseline)

1. Home page has <title>, meta description, and one <h1>.
2. Monitoring Agent report contains a Summary section and Page details.
3. Orphan pages list does not include the homepage.
