# Readiness Checklist (Rapid Start)

- [ ] Executive mandate & scope (virtauto.de Website-MAS)
- [ ] Roles & decision rights (RASCI)
- [ ] Data access for grounding (Analytics, sitemap, repo)
- [ ] AgentOps telemetry on
- [ ] Reproducible tests pass locally & in CI
- [ ] 90-day plan with KPIs per agent
