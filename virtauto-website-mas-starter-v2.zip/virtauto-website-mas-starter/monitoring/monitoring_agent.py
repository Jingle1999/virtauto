#!/usr/bin/env python3
import argparse
import os
import re
import sys
import time
import tldextract
import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from collections import deque, defaultdict
from datetime import datetime

USER_AGENT = "virtauto-monitor/0.1 (+https://www.virtauto.de)"

def is_internal(link, base_netloc):
    parsed = urlparse(link)
    if not parsed.netloc:
        return True
    # consider subdomains internal
    base = tldextract.extract(base_netloc)
    cur = tldextract.extract(parsed.netloc)
    return (base.domain == cur.domain) and (base.suffix == cur.suffix)

def normalize_url(url):
    # remove fragments and normalize
    p = urlparse(url)
    return p._replace(fragment="").geturl()

def fetch(url, timeout=15):
    try:
        resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=timeout, allow_redirects=True)
        return resp
    except Exception as e:
        return None

def extract_links(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    links = set()
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.startswith("mailto:") or href.startswith("tel:") or href.startswith("javascript:"):
            continue
        abs_url = urljoin(base_url, href)
        links.add(normalize_url(abs_url))
    return links

def basic_seo_checks(html):
    soup = BeautifulSoup(html, "html.parser")
    title = (soup.title.string.strip() if soup.title and soup.title.string else "")
    meta_desc = ""
    canonical = ""
    h1 = ""
    md = soup.find("meta", attrs={"name": "description"})
    if md and md.get("content"):
        meta_desc = md["content"].strip()
    can = soup.find("link", attrs={"rel": ["canonical", "Canonical"]})
    if can and can.get("href"):
        canonical = can["href"].strip()
    h1_tag = soup.find("h1")
    if h1_tag:
        h1 = h1_tag.get_text(strip=True)
    return {
        "has_title": bool(title),
        "has_meta_description": bool(meta_desc),
        "has_h1": bool(h1),
        "has_canonical": bool(canonical),
        "title_len": len(title),
        "meta_description_len": len(meta_desc)
    }

def crawl(base_url, max_pages=50):
    parsed = urlparse(base_url)
    base_netloc = parsed.netloc or urlparse("https://" + base_url).netloc

    visited = set()
    queue = deque([normalize_url(base_url)])
    results = {}
    link_graph = defaultdict(set)

    while queue and len(visited) < max_pages:
        url = queue.popleft()
        if url in visited:
            continue
        visited.add(url)

        resp = fetch(url)
        status = None if resp is None else resp.status_code
        text = "" if resp is None else resp.text

        results[url] = {
            "status": status,
            "ok": (resp is not None and 200 <= resp.status_code < 400),
            "seo": basic_seo_checks(text) if resp is not None and resp.headers.get("content-type","").startswith("text/html") else {}
        }

        # only crawl internal HTML pages
        if resp is not None and resp.ok and "text/html" in resp.headers.get("content-type",""):
            links = extract_links(text, url)
            for l in links:
                if is_internal(l, base_netloc):
                    link_graph[url].add(l)
                    if l not in visited and len(visited) + len(queue) < max_pages:
                        queue.append(l)

    # Check external links (status only)
    external_status = {}
    for src, links in link_graph.items():
        for l in links:
            if not is_internal(l, base_netloc) and l not in external_status:
                r = fetch(l)
                external_status[l] = None if r is None else r.status_code

    return results, link_graph, external_status

def make_report(base_url, results, link_graph, external_status):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
    total = len(results)
    broken = sum(1 for r in results.values() if (r["status"] is None or (r["status"] >= 400)))
    ok = sum(1 for r in results.values() if r["ok"])
    missing_title = sum(1 for r in results.values() if r["seo"] and not r["seo"].get("has_title"))
    missing_desc = sum(1 for r in results.values() if r["seo"] and not r["seo"].get("has_meta_description"))
    missing_h1 = sum(1 for r in results.values() if r["seo"] and not r["seo"].get("has_h1"))
    missing_canonical = sum(1 for r in results.values() if r["seo"] and not r["seo"].get("has_canonical"))
    orphan_pages = []
    # build reverse links
    incoming = defaultdict(int)
    for src, links in link_graph.items():
        for l in links:
            incoming[l] += 1
    for url in results.keys():
        if incoming[url] == 0 and url != base_url:
            orphan_pages.append(url)

    lines = []
    lines.append(f"# virtauto Monitoring Report")
    lines.append(f"- Timestamp: {ts}")
    lines.append(f"- Base URL: {base_url}")
    lines.append("")
    lines.append("## Summary")
    lines.append(f"- Pages crawled: **{total}**")
    lines.append(f"- OK (2xx/3xx): **{ok}**")
    lines.append(f"- Broken (>=400 or error): **{broken}**")
    lines.append("")
    lines.append("## On-page SEO (basics)")
    lines.append(f"- Missing `<title>`: **{missing_title}**")
    lines.append(f"- Missing meta description: **{missing_desc}**")
    lines.append(f"- Missing `<h1>`: **{missing_h1}**")
    lines.append(f"- Missing canonical: **{missing_canonical}**")
    lines.append("")
    if orphan_pages:
        lines.append("## Orphan pages (no internal incoming links)")
        for u in sorted(orphan_pages)[:50]:
            lines.append(f"- {u}")
        if len(orphan_pages) > 50:
            lines.append(f"- ... (+{len(orphan_pages)-50} more)")
        lines.append("")
    if external_status:
        broken_external = [u for u,s in external_status.items() if (s is None or s >= 400)]
        lines.append("## External link status (sample)")
        lines.append(f"- Checked: {len(external_status)}")
        lines.append(f"- Broken external links: {len(broken_external)}")
        if broken_external:
            for u in broken_external[:50]:
                s = external_status[u]
                lines.append(f"  - {u} -> {s}")
        lines.append("")

    lines.append("## Page details")
    for url, r in results.items():
        status = r["status"]
        ok = r["ok"]
        seo = r["seo"]
        lines.append(f"- {url}")
        lines.append(f"  - status: {status}")
        if seo:
            lines.append(f"  - seo: title={seo.get('has_title')}, meta_desc={seo.get('has_meta_description')}, h1={seo.get('has_h1')}, canonical={seo.get('has_canonical')} (title_len={seo.get('title_len')}, meta_len={seo.get('meta_description_len')})")
    return "\n".join(lines)

def main():
    started = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    parser = argparse.ArgumentParser(description="virtauto Monitoring Agent")
    parser.add_argument("--base-url", required=True, help="Base URL to crawl, e.g., https://www.virtauto.de")
    parser.add_argument("--max-pages", type=int, default=50, help="Max pages to crawl")
    parser.add_argument("--output", default="logs/agent_reports.md", help="Report output path")
    args = parser.parse_args()

    base_url = args.base_url.rstrip("/")
    results, link_graph, external_status = crawl(base_url, max_pages=args.max_pages)
    report = make_report(base_url, results, link_graph, external_status)

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(report)
    # telemetry
    duration_ms = 0
    try:
        duration_ms = 0
    except Exception:
        duration_ms = 0
    errors_count = sum(1 for r in results.values() if (r['status'] is None or (r['status'] and r['status'] >= 400)))
    emit_telemetry(base_url, results, started, duration_ms, errors_count)
    print(f"Wrote report to {args.output} and appended telemetry to ops/run_telemetry.jsonl")

if __name__ == "__main__":
    main()


import hashlib, json

def emit_telemetry(base_url, results, started_ts, duration_ms, errors_count):
    os.makedirs("ops", exist_ok=True)
    out = {
        "timestamp_utc": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "agent": "MonitoringAgent",
        "run_id": hashlib.md5((base_url + started_ts).encode()).hexdigest(),
        "input": {"base_url": base_url, "pages": len(results)},
        "output_hash": hashlib.md5(str(list(results.keys())).encode()).hexdigest(),
        "duration_ms": duration_ms,
        "errors": errors_count,
        "decisions": ["report_written"],
        "kpis": {},
        "notes": ""
    }
    with open("ops/run_telemetry.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(out) + "\n")
