# virtauto Website-MAS Starter (v2)

This starter turns **virtauto.de** into a small **Multi-Agent System** that monitors, maintains,
and evolves the website. It now integrates additional principles from:
- *Google Startup Technical Guide – AI Agents* (Grounding, AgentOps, Reproducibility)
- *AI Transformation Readiness Diagnostic* (Value-anchoring, Governance, Safe-to-Operate, Continuous Readiness)

## What’s new in v2
- **Grounding**: Each agent must declare its trusted data sources.
- **AgentOps**: Telemetry, logs, and run reports captured to `/ops/` and GitHub Actions artifacts.
- **Reproducible Tests**: Minimal test cases under `/tests/` to constrain non-determinism.
- **Governance & Readiness**: RASCI, safe-to-operate baseline, value cases per agent under `/governance/`.

## Quick Start

1. Copy this folder into your website repo (root level).
2. Set GitHub Secret `SITE_BASE_URL=https://www.virtauto.de` (or preview URL).
3. Install deps locally:
   ```bash
   pip install -r monitoring/requirements.txt
   ```
4. Run the Monitoring Agent locally:
   ```bash
   python monitoring/monitoring_agent.py --base-url https://www.virtauto.de --max-pages 50
   ```
5. Commit & push. The GitHub Action runs and uploads `logs/agent_reports.md` and `/ops/run_telemetry.json` as artifacts.

## Folders
- `/agents` — roles and guardrails (GEORGE, Content, Design, Code, Consistency, Monitoring)
- `/config` — orchestrator config
- `/monitoring` — crawler & SEO basics
- `/tests` — reproducible test cases (baseline assertions)
- `/ops` — AgentOps: telemetry schema, run logs, playbook
- `/governance` — value cases, RASCI, safe-to-operate checklist, readiness checklist
- `/.github/workflows` — CI for monitoring and telemetry upload
- `/logs` — human-readable reports

## Notes
- Lighthouse is optional; enable later in the workflow.
- Extend with Content/Design/Code agents using your preferred framework (CrewAI/AutoGen/LangGraph).
