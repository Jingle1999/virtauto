Drop these files into your repo root. Keep news.json in the root as before. index.html is the dashboard; home.html is the landing page.
