# virtauto Glossary (MVP)

- **MAS** → Always expand to "Multi-Agent System"
- **AI** → First mention as "Artificial Intelligence (AI)", later "AI"
- **SCM** → Always expand to "Supply Chain Management"
- **Spelling** → Use US spelling: "color" (not "colour")
- **Hyphenation** → "Multi-Agent System" (with hyphen)
